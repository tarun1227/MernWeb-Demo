
import './App.css';
import { BrowserRouter } from "react-router-dom";
import All from "./components/All"

function App() {
  return (
    <>
   <BrowserRouter>
   <All />
   </BrowserRouter>
    </>
  );
}

export default App;
