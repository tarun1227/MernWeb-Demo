import React, { useEffect, useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import {useHistory} from 'react-router-dom';
import aboutpic from '../images/tarun.png'

function About() {
 
  const history = useHistory();

  const [userData, setUserData] = useState({});

  const callAboutUs = async() =>{
    try{
      const res = await fetch('/about', {
        method : "GET",
        headers: {
          Accept:"application/json",
          "Content-Type":"application/json"
        },
        credentials:"include"
      });

      const data = await res.json();
      console.log(data);
      setUserData(data);

      if(!res.status === 200){
          const error = new Error(res.error);
          throw error;
      }

    }catch(err){
      console.log(err);
      history.push('/login');
    }
  }

  useEffect( () => {
      callAboutUs();
  },[])

  return ( 
    <>
    <div className="container shadow mt-3 emp-profile">
     <form method="GET">

      <div className="row mt-5 ">
        <div className="col-md-4 mt-4">
          <img src="" style={{width:"150px",height:"200px"}} alt="profile-pic"/>
        </div>

        <div className="col-md-6 mt-4">
        <div className="profile-head">
          <h5>{ userData.name }</h5>
          <h6>Web Developer</h6>
          <p className="mt-5 mb-5">RANKING : <span>1/10</span></p>

          <ul  class="nav nav-pills">
			     <li class="active">
             <a className="text-decoration-none"  href="#about" data-toggle="tab">About</a>
			     </li>
		    	<li>
            <a className="text-decoration-none pl-3" href="#timeline" data-toggle="tab">Timeline </a>
			    </li>
		     </ul>

        </div>
      </div>

      <div className="col-md-2 mt-4 mt-lg-4">
       <input type="submit" className="profile-edit-btn" value="profile-edit"/>
      </div>

      </div>

      <div className="row">
        {/* leftside */}
        <div className="col-md-4">
          <div className="profle-work">
            <p> Work Link</p>
            <a href="#" target="_thapa">youtube</a><br/>
            <a href="#" target="_thapa">LinkedIn</a><br/>
            <a href="#" target="_thapa">Indeed</a><br/>
            <a href="#" target="_thapa">Noukri</a><br/>
          </div>
        </div>
        

        {/* rightside */}
        <div className="col-md-8 pl-4 about-info">
          
			<div class="tab-content clearfix">
			  <div class="tab-pane active" id="about">
        <div className="row mt-3">
                <div className="col-md-6">
                  <label>user ID</label>
                </div>
                <div className="col-md-6">
                  <p>{userData._id}</p>
                </div>
              </div>

              <div className="row">
                <div className="col-md-6">
                  <label>Name</label>
                </div>
                <div className="col-md-6">
                  <p>{userData.name}</p>
                </div>
              </div>

              <div className="row">
                <div className="col-md-6">
                  <label>Email</label>
                </div>
                <div className="col-md-6">
                  <p>{userData.email}</p>
                </div>
              </div>

              <div className="row">
                <div className="col-md-6">
                  <label>Phone</label>
                </div>
                <div className="col-md-6">
                  <p>{userData.phone}</p>
                </div>
              </div>
				</div>
				<div class="tab-pane" id="timeline">
          <h3>We use the class nav-pills instead of nav-tabs which automatically creates a background color for the tab</h3>
				</div>
			</div>
        </div>
      </div>
     </form>
    </div>
    </>
  );
}

export default About;